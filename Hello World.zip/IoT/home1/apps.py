from django.apps import AppConfig


class Home1Config(AppConfig):
    name = 'home1'
